#include "userprog/syscall.h"
#include "userprog/process.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "devices/shutdown.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  uint32_t *esp = f->esp;
  uint32_t sys_num = *esp;
  
  /* System Call Table: Call a corresponding routine
	 to perform system function requested by user program */
  switch (sys_num)
  {
  case SYS_HALT:		/* Halt the operating system. */
	  halt();
	  break;

  case SYS_EXIT:		/* Terminate the process. */
	  USER_ADDR_CHECK(1);		// Check whether it's in user space
	  exit(ARG(1, int));					// Use C-Macro for readability
	  break;

  case SYS_EXEC:		/* Start another process. */
	  USER_ADDR_CHECK(1);
	  f->eax = exec(ARG(1, char*));
	  break;

  case SYS_WAIT:		/* Wait for a child process to die. */
	  USER_ADDR_CHECK(1);
	  f->eax = wait(ARG(1, pid_t));
	  break;

  case SYS_READ:		/* Read from a file. */
	  USER_ADDR_CHECK(3);
	  f->eax = read(ARG(1, int), ARG(2, void*), ARG(3, unsigned));
	  break;

  case SYS_WRITE:		/* Write to a file. */
	  USER_ADDR_CHECK(3);
	  f->eax = write(ARG(1, int), ARG(2, void*), ARG(3, unsigned));
	  break;

  case SYS_FIBONACCI:	/* Calculate the N-th fibonacci number */
	  USER_ADDR_CHECK(1);
	  f->eax = fibonacci(ARG(1, int));
	  break;

  case SYS_MAXOFFOUR:	/* Calculate the maximum among four integers */
	  USER_ADDR_CHECK(4);
	  f->eax = max_of_four_int(ARG(1, int), ARG(2, int), ARG(3, int), ARG(4, int));
	  break;

  // Only 8 system calls are implemented for now (Project 1 (Sogang OS))
  default: break;
  }
}

/* Halt routine: it terminates pintOS via shutdown func */
void 
halt (void) 
{
	shutdown_power_off();
}

/* Exit routine: simply stores an exit status of running thread,
	and calls 'thread_exit'. 'thread_exit' will do the main job! */
void 
exit (int status) 
{
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current()->exit_status = status;			// record the exit status
	thread_exit();
}

/* Exec routine: simply calls 'process_execute'. 
	Again, 'process_execute' will do the main 'execution' job! */
tid_t 
exec (const char* cmd_line) 
{
	return process_execute(cmd_line);
}

/* Wait routine: simply calls 'process_wait' */
int 
wait (tid_t pid) 
{
	return process_wait(pid);
}

/* Read routine: reads 'size' bytes from the standard input and
	returns the read bytes. It uses 'input_getc' func from 'input.h' */
int 
read (int fd, void* buffer, unsigned size)
{
	unsigned byte_cnt = 0, i;
	char c;

	if (fd == 0) /* STDIN_FILENO */
	{
		for (i = 0; (i < size) && ((c = input_getc()) != '\0'); i++) 
		{
			*((char*)buffer) = c;			// read per character
			buffer = (char*)buffer + 1;
			byte_cnt++;
		}
		*((char*)buffer) = '\0';
	}
	else byte_cnt = -1;						// exception

	return byte_cnt;
}

/* Write routine: writes 'size' bytes from 'buffer' to the standard
	output and returns the written bytes count. */
int 
write (int fd, const void* buffer, unsigned size) 
{
	unsigned byte_cnt = 0;

	if (fd == 1) /* STDOUT_FILENO */
	{
		putbuf(buffer, size);		// writes as many bytes as possible
		byte_cnt += size;
	}
	else byte_cnt = 0;

	return byte_cnt;
}

/* Fibonacci routine: returns N-th value of fibonacci sequence.
	It produces sequence with simple iterative algorithm. */
int 
fibonacci (int n) 
{
	int f = 0, f1 = 1, f2 = 0;
	int i;

	if (n == 0) return 0;
	if (n == 1) return 1;
	for (i = 2; i <= n; i++) 
	{
		f = f1 + f2;
		f2 = f1;
		f1 = f;
	}

	return f;
}

/* Max_of_four_int routine: returns the maximum among arbitrary decimals 
	It uses simple bubble-sort to figure out the maximum. */
int 
max_of_four_int (int a, int b, int c, int d)
{
	int arr[4], temp;
	int i, j;

	arr[0] = a; arr[1] = b; arr[2] = c; arr[3] = d;
	for (i = 0; i < 3; i++) 
		for (j = i + 1; j < 4; j++) 
		{
			if (arr[i] > arr[j]) 
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}

	return arr[3];		// ascending order sorting
}
