#include "userprog/syscall.h"
#include "userprog/process.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "devices/shutdown.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "lib/string.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  lock_init(&access_lock);		            // initialized the access lock
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  uint32_t *esp = f->esp;
  uint32_t sys_num = *esp;
  
  /* System Call Table: Call a corresponding routine
     to perform system function requested by user program */
  switch (sys_num)
  {
  case SYS_HALT:        /* Halt the operating system. */
      halt();
      break;

  case SYS_EXIT:        /* Terminate the process. */
      USER_ADDR_CHECK(1);       // Check whether it's in user space
      exit(ARG(1, int));        // Use C-Macro for readability
      break;

  case SYS_EXEC:        /* Start another process. */
      USER_ADDR_CHECK(1);
      f->eax = exec(ARG(1, char*));
      break;

  case SYS_WAIT:        /* Wait for a child process to die. */
      USER_ADDR_CHECK(1);
      f->eax = wait(ARG(1, pid_t));
      break;

  case SYS_CREATE:      /* Create a file. */
      USER_ADDR_CHECK(2); 
      f->eax = create(ARG(1, char*), ARG(2, unsigned));
      break;

  case SYS_REMOVE:      /* Delete a file. */
      USER_ADDR_CHECK(1);
      f->eax = remove(ARG(1, char*));
      break;

  case SYS_OPEN:        /* Open a file. */
      USER_ADDR_CHECK(1);
      f->eax = open(ARG(1, char*));
      break;

  case SYS_FILESIZE:    /* Obtain a file's size. */
      USER_ADDR_CHECK(1);
      f->eax = filesize(ARG(1, int));
      break;

  case SYS_READ:        /* Read from a file. */
      USER_ADDR_CHECK(3);
      f->eax = read(ARG(1, int), ARG(2, void*), ARG(3, unsigned));
      break;

  case SYS_WRITE:       /* Write to a file. */
      USER_ADDR_CHECK(3);
      f->eax = write(ARG(1, int), ARG(2, void*), ARG(3, unsigned));
      break;

  case SYS_SEEK:        /* Change position in a file. */
      USER_ADDR_CHECK(2);
      seek(ARG(1, int), ARG(2, unsigned));
      break;

  case SYS_TELL:        /* Report current position in a file. */
      USER_ADDR_CHECK(1);
      f->eax = tell(ARG(1, int));
      break;

  case SYS_CLOSE:       /* Close a file. */
      USER_ADDR_CHECK(1);
      close(ARG(1, int));
      break;

  case SYS_FIBONACCI:   /* Calculate the N-th fibonacci number */
      USER_ADDR_CHECK(1);
      f->eax = fibonacci(ARG(1, int));
      break;

  case SYS_MAXOFFOUR:   /* Calculate the maximum among four integers */
      USER_ADDR_CHECK(4);
      f->eax = max_of_four_int(ARG(1, int), ARG(2, int), ARG(3, int), ARG(4, int));
      break;

  default: break;
  }
}

/* Halt routine: it terminates pintOS via shutdown func */
void 
halt (void) 
{
    shutdown_power_off();
}

/* Exit routine: stores an exit status of running thread, with
   closing all the not-closed files in the FDT. After that, reaps
   every child process that this current process forked and calls
   'thread_exit' to do the main thread-clearing job */
void 
exit (int status) 
{
    struct file **f_list;
    struct list *c_list;
    struct list_elem *iter;
    int i;

    printf("%s: exit(%d)\n", thread_name(), status);
    thread_current()->exit_status = status;			// record the exit status

    /* Close all the not-closed files in the FDT */
    f_list = &(thread_current()->fd);
    for (i = 0; i < FD_MAX; i++)
    {
        if (f_list[i] != NULL)
            close(i);
    }

    /* Reap every child process that this(parent) process forked */
    c_list = &(thread_current()->child_list);
    for (ITERATE_C_LIST)               // iterate the list of child processes
        wait(EACH_CHILD->tid);         // reap each entry(child) with 'wait'
    
    thread_exit();
}

/* Exec routine: simply calls 'process_execute'. 
   'process_execute' will do the main 'execution' job! */
tid_t 
exec (const char* cmd_line) 
{
    return process_execute(cmd_line);
}

/* Wait routine: simply calls 'process_wait' */
int 
wait (tid_t pid) 
{
    return process_wait(pid);
}

/* Create routine: checks the value of pointer variable
   and simply calls 'filesys_create' func of filesys.h */
bool
create(const char* file, unsigned initial_size)
{
    POINTER_CHECK(file);
    return filesys_create(file, initial_size);
}

/* Remove routine: implemented just like 'create' above */
bool
remove(const char* file)
{
    POINTER_CHECK(file);
    return filesys_remove(file);
}

/* Open routine: opens the corresponding file structure
   of the target file, with assigning a proper descriptor.
   We should guarantee two things here.
    - only one process at a time can access this code. 
    - if a file is as same as the running program, then
      deny any write operations on that file */
int
open(const char* file)
{
    struct file **fd_list;
    struct file *f;
    int i, idx;

    POINTER_CHECK(file);                    // check if a pointer is valid
    lock_acquire(&access_lock);             // give mutual exclusion for here

    /* Open 'open file table' of the input file. 
       If open fails, then return with -1 status */
    f = filesys_open(file);
    if (f == NULL)
    {
        lock_release(&access_lock);
        return OPEN_FILE_ERROR;
    }

    /* If a file is as same as the running program,
       then deny any write operations on this file */
    if (!strcmp(thread_name(), file))
        file_deny_write(f);

    /* Assign proper file descriptor to file struct */
    fd_list = &(thread_current()->fd);
    for (i = 3; i < FD_MAX; i++) 
    {
        if (fd_list[i] == NULL)
        {
            fd_list[i] = f;
            idx = i;
            break;                          // first-fit approach
        }
    }
    if (i == FD_MAX)                        // if FDT is full, then
    {                                       //  return with -1 status
        lock_release(&access_lock);
        return OPEN_FILE_ERROR;
    }
    lock_release(&access_lock);             // retrieve the mutual exclusion

    return idx;                             // return the file descriptor
}

/* Filesize routine: simply calls 'file_length' function. */
int
filesize(int fd)
{
    struct file *f;

    if (fd < 3 || fd >= FD_MAX) exit(-1);     // descriptor error handling
    f = thread_current()->fd[fd];             // get corresponding file struct
    if (f == NULL) exit(-1);                  // file struct error handling

    return file_length(f);
}

/* Read routine: reads 'size' bytes from the file pointed 
   by fd, and stores it to buffer. We should guarantee 
   one thing below. (same for the next 'write' routine)
    - only one process at a time can access this code. */
int 
read (int fd, void *buffer, unsigned size)
{
    struct file *f;
    off_t byte_cnt = 0; 
    char c; int i;

    POINTER_CHECK(buffer);
    lock_acquire(&access_lock);             // give mutual exclusion for here
    
    if (fd == 0) 
    {   /* STDIN_FILENO */
        for (i = 0; (i < size) && ((c = input_getc()) != '\0'); i++)
        {
            *((char*)buffer) = c;			// read per character
            buffer = (char*)buffer + 1;
            byte_cnt++;
        }
        *((char*)buffer) = '\0';
    }
    else if (fd < 3 || fd >= FD_MAX)
    {   /* File descriptor error */
        lock_release(&access_lock);
        exit(-1);
    }
    else 
    {   /* Any I/O-possible files */
        f = thread_current()->fd[fd];       // get corresponding file struct
        if (f == NULL)                      // file struct error handling
        {
            lock_release(&access_lock);
            exit(-1);
        }
        
        byte_cnt = file_read(f, buffer, size);      // read with 'file_read'
    }
    lock_release(&access_lock);             // retrieve the mutual exclusion

    return byte_cnt;
}

/* Write routine: writes 'size' bytes of buffer to the file 
   pointed by fd, We should guarantee two things here.
    - only one process at a time can access this code. 
    - if a file is as same as the running program, then
      deny any write operations on that file */
int 
write (int fd, const void *buffer, unsigned size) 
{
    struct file *f;
    off_t byte_cnt = 0;

    POINTER_CHECK(buffer);
    lock_acquire(&access_lock);

    if (fd == 1) 
    {   /* STDOUT_FILENO */
        putbuf(buffer, size);		      // writes as many bytes as possible
        byte_cnt += size;
    }
    else if (fd < 3 || fd >= FD_MAX)
    {   /* File descriptor error */
        lock_release(&access_lock);
        exit(-1);
    }
    else 
    {   /* Any I/O-possible files */
        f = thread_current()->fd[fd];
        if (f == NULL)
        {
            lock_release(&access_lock);
            exit(-1);
        }
        if (f->deny_write == true)       // if this file is running program,
            file_deny_write(f);          //  then deny write operations on it.

        byte_cnt = file_write(f, buffer, size);     // write with 'file_write'
    }
    lock_release(&access_lock);

    return byte_cnt;
}

/* Seek routine: simply calls 'file_seek' function. 
   This is implemented just like the 'filesize' syscall 
   Same for the 'tell' syscall below. (The reason why these
   are implemented simply is that pintOS provides the 
   complete basic file system with filesys.h) */
void
seek(int fd, unsigned position)
{
    struct file *f;

    if (fd < 3 || fd >= FD_MAX) exit(-1);
    f = thread_current()->fd[fd];
    if (f == NULL) exit(-1);

    file_seek(f, position);
}

/* Tell routine: simply calls 'file_tell' function. */
unsigned
tell(int fd)
{
    struct file *f;

    if (fd < 3 || fd >= FD_MAX) exit(-1);
    f = thread_current()->fd[fd];
    if (f == NULL) exit(-1);

    return file_tell(f);
}

/* Close routine: simply calls 'file_close' function. */
void
close(int fd)
{
    struct file *f;

    if (fd < 3 || fd >= FD_MAX) exit(-1);
    f = thread_current()->fd[fd];
    if (f == NULL) exit(-1);

    thread_current()->fd[fd] = NULL;        // record as NULL

    file_close(f);  // This func performs not only the closing-file routine, 
}                   // but also the 'file_allow_write' for running programs

/* Fibonacci routine: returns N-th value of fibonacci sequence.
    It produces sequence with simple iterative algorithm. */
int 
fibonacci (int n) 
{
    int f = 0, f1 = 1, f2 = 0;
    int i;

    if (n == 0) return 0;
    if (n == 1) return 1;
    for (i = 2; i <= n; i++) 
    {
        f = f1 + f2;
        f2 = f1;
        f1 = f;
    }

    return f;
}

/* Max_of_four_int routine: returns the maximum among arbitrary decimals 
    It uses simple bubble-sort to figure out the maximum. */
int 
max_of_four_int (int a, int b, int c, int d)
{
    int arr[4], temp;
    int i, j;

    arr[0] = a; arr[1] = b; arr[2] = c; arr[3] = d;
    for (i = 0; i < 3; i++) 
        for (j = i + 1; j < 4; j++) 
        {
            if (arr[i] > arr[j]) 
            {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

    return arr[3];		// ascending order sorting
}
