#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#define bool	_Bool

void syscall_init (void);

#define ARG_ADDR(k) ((uint8_t*)esp + 4*k)
// ARG_ADDR: returns the address of given passed-by-syscall arguments

#define ARG(k, type) *(type*)(ARG_ADDR(k))
// ARG: returns the value of given pointer, by casting of 'type'

/* Macros for readability of codes (whole) */
#define POINTER_CHECK(vaddr) if (vaddr == NULL || is_user_vaddr(vaddr) == false) exit(-1);
// POINTER_CHECK: checks if an argument is in the user address space
//	  with pre-provided 'is_user_vaddr' function. And, check NULL also!
#define USER_ADDR_CHECK(param_num) for(int i=1;i<=param_num;i++){POINTER_CHECK(ARG_ADDR(i))}
// USER_ADDR_CHECK: checks all the parameters that a system call needs
//    with consequtively calling 'POINTER_CHECK' macro above!

#define OPEN_FILE_ERROR -1
// OPEN_FILE_ERROR: indicates that an error occurs in the 'open' syscall

typedef int pid_t;

/* Binary semaphore providing the mutual exclusion
   while accessing file-related system calls */
struct lock access_lock;                    // protect the critical section

/* Routines to perform each system call functionality */
void halt(void);
void exit(int status);
pid_t exec(const char* cmd_line);
int wait(pid_t pid);
bool create(const char* file, unsigned initial_size);
bool remove(const char* file);
int open(const char* file);
int filesize(int fd);
int read(int fd, void* buffer, unsigned size);
int write(int fd, const void* buffer, unsigned size);
void seek(int fd, unsigned position);
unsigned tell(int fd);
void close(int fd);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);

#endif /* userprog/syscall.h */
