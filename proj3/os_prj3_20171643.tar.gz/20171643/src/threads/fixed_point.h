#ifndef THREADS_FIXED_POINT_H
#define THREADS_FIXED_POINT_H

#include <stdint.h>

/* Fixed-Point Real Arithmetic

   The format of the fixed-point real type in this project(#3)
   is just like a figure below.

   -----------------------------------------------------------
   |   0    /    00000000000000000    /    00000000000000    |
   -----------------------------------------------------------
   | Sign(1)/       Integer(17)       /     Fraction(14)     |
   -----------------------------------------------------------

     * Total 4 bytes (32 bits) for representing reals
     * MSB indicates the sign of a real value
     * Next 17 bits are indicating the integer part of real
     * Last 14 bits are indicating the fraction part of real

   pintOS will use this 'real' type to implement the calculation
   of priority aging technique, especially in 'recent_cpu', 'load_avg'
*/
/* Type definitions of 'REAL' type. Users are recommended to
   use only 'real_t' for indicating this fixed-point type */
typedef int32_t real32_t;
typedef int64_t real64_t;
typedef real32_t real_t;

/* Macros for readability (meaning) */
#define FRACTION (1 << 14)
// It means the fraction part of real
#define MAKE_REAL(num) num * FRACTION
// Type casting (up_to_real)
#define MAKE_REAL_DOWN(num) num / FRACTION
// Type casting (down_to_real)
#define MAKE_INT(num) num / FRACTION
// Type casting (real_to_integer)

/** Add operations **/
/* (1) real_t + int */
#define R_ADD_I(real, integer) (real32_t)(real + MAKE_REAL(integer))
/* (2) int + real_t */
#define I_ADD_R(integer, real) (R_ADD_I(real, integer))
/* (3) real_t + real_t */
#define R_ADD_R(real1, real2) (real32_t)(real1 + real2)

/** Sub operations **/
/* (1) real_t - int */
#define R_SUB_I(real, integer) (real32_t)(real - MAKE_REAL(integer))
/* (2) int - real_t */
#define I_SUB_R(integer, real) (real32_t)(MAKE_REAL(integer) - real)
/* (3) real_t - real_t */
#define R_SUB_R(real1, real2) (real32_t)(real1 - real2)

/** Mul operations **/
/* (1) int * real_t */
#define I_MUL_R(integer, real) (real32_t)(integer * real)
/* (2) real_t * int */
#define R_MUL_I(real, integer) (I_MUL_R(integer, real))
/* (3) real_t * real_t */
#define R_MUL_R(real1, real2) (real32_t)(MAKE_REAL_DOWN((real64_t)real1 * (real64_t)real2))

/** Div operations **/
/* (1) real_t / int */
#define R_DIV_I(real, integer) (real32_t)(real / integer)
/* (2) int / real_t */
#define I_DIV_R(integer, real) (real32_t)(MAKE_REAL(integer) / real)
/* (3) real_t / real_t */
#define R_DIV_R(real1, real2) (real32_t)(MAKE_REAL((real64_t)real1) / (real64_t)real2)

#endif /* threads/fixed_point.h */