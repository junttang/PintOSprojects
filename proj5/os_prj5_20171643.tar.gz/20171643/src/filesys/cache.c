#include "filesys/cache.h"
#include "filesys/filesys.h"
#include <string.h>
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"

/* Format of each entry in the buffer cache. */
struct cache_entry 
{
  /* Data part of each slot. */
  uint8_t block[BLOCK_SECTOR_SIZE]; /* The associated sector. */
  block_sector_t disk_sector;       /* The associated sector #. */

  /* Metadata of each slot. */
  int open_cnt;                     /* Reference count of slot. */
  bool is_free;                     /* Is this slot freed? */
  bool is_accessed;                 /* Is this slot accessed? */
  bool is_dirty;                    /* Is this slot modified? */
};

/* Maximum size of buffer cache. */
#define CACHE_SIZE 64

/* Buffer cache. */
struct cache_entry cache[CACHE_SIZE];

/* For a mutual exclusion of buffer cache. */
struct lock cache_lock;

/* Eviction routine should be protected. */
static int cache_evict_entry (block_sector_t disk_sector, bool is_dirty);

/* Initialize the buffer cache. */
void 
cache_init (void)
{
  int i;
  /* Initialize each slot as 'freed'. */
  for (i = 0; i < CACHE_SIZE; i++)
    {
      cache[i].open_cnt = 0;
      cache[i].is_free = true;
      cache[i].is_accessed = false;
      cache[i].is_dirty = false;
    }

  /* Initialize the mutex lock. */
  lock_init (&cache_lock);

  //thread_create ("cache_writeback", 0, write_behind_routine, NULL);
}

/* Access the slot of buffer cache, indicated by the given sector #.
   That is, only inode operations call this interface. 
   Note that before reading or writing the slot, inode structure must
   access the slot first by calling this function. */
int 
cache_access_entry (block_sector_t disk_sector, bool is_dirty)
{
  int idx = -1, i;
  
  lock_acquire (&cache_lock);

  /* First, find the corresponding slot in the buffer cache. */
  for (i = 0; i < CACHE_SIZE; i++) 
    {
      if (cache[i].disk_sector == disk_sector &&
          cache[i].is_free == false)
        { 
          idx = i;
          break;
        }
    }

  /* If there's no freed slot, that is, the cache is
     full, then let's do an eviction! */
  if (idx == -1)
    idx = cache_evict_entry (disk_sector, is_dirty);
  else
    {
      cache[idx].open_cnt++;
      cache[idx].is_accessed = true;
      cache[idx].is_dirty |= is_dirty;
    }

  lock_release (&cache_lock);

  return idx;
}

/* Read operation over buffer cache slot.
   Since this function doesn't have any condition check routines,
   caller must be careful to pass inappropriate arguments. */
void
cache_read_entry (int buffer_idx, off_t bytes_read, 
  uint8_t* buffer, int sector_ofs, int chunk_size)
{
  memcpy (buffer + bytes_read, cache[buffer_idx].block 
    + sector_ofs, chunk_size);
  cache[buffer_idx].open_cnt--;
  cache[buffer_idx].is_accessed = true;
}

/* Write operation over buffer cache slot. 
   Since this function doesn't have any condition check routines,
   caller must be careful to pass inappropriate arguments. */
void
cache_write_entry(int buffer_idx, off_t bytes_written,
    uint8_t* buffer, int sector_ofs, int chunk_size)
{
  memcpy (cache[buffer_idx].block + sector_ofs, 
    buffer + bytes_written, chunk_size);
  cache[buffer_idx].open_cnt--;
  cache[buffer_idx].is_accessed = true;
  cache[buffer_idx].is_dirty = true;
}

/* Total write-behind (flushing) routine of buffer cache.
   That is, this function will be called when there's an
   abnormal termination of pintOS, or unmounting of file system. */
void 
cache_flush (void)
{
  int i;

  lock_acquire (&cache_lock);

  /* Iterate all the slots in the buffer cache, with
     updating dirty blocks into the disk. */
  for (i = 0; i < CACHE_SIZE; i++)
    {
      if (cache[i].is_dirty == true)
        {
          block_write (fs_device, cache[i].disk_sector, 
            &cache[i].block);
          cache[i].is_dirty = false;
        }

      cache[i].open_cnt = 0;
      cache[i].is_free = true;
      cache[i].is_accessed = false;
      cache[i].is_dirty = false;
    }

  lock_release (&cache_lock);
}

/* Clock (Second Chance) Algorithm based eviction routine. */
static int 
cache_evict_entry (block_sector_t disk_sector, bool is_dirty)
{
  int idx = -1, i; /* i is iterator. */

  /* First, check if there're any freed slot
     in the buffer cache. */
  for (i = 0; i < CACHE_SIZE; i++)
    {
      if (cache[i].is_free == true)
      {
        cache[i].is_free = false;
        idx = i;
        break;
      }
    }

  i = 0;
  /* If the cache is full, let's do an eviction. */
  if (idx == -1)
    {
      while (1) 
        {
          /* If the slot is currently used, 
             we should not touch it. */
          if (cache[i].open_cnt > 0)
            continue;

          /* Give a second chance to slot, if it's accessed. */
          if (cache[i].is_accessed == true)
            cache[i].is_accessed = false;

          /* If the slot isn't accessed before, then evict it. */
          else
            { 
              /* If the slot is dirty, then write behind to disk. */
              if (cache[i].is_dirty == true)
                block_write (fs_device, cache[i].disk_sector,
                  &cache[i].block);

              /* Free the slot. */
              cache[i].open_cnt = 0;
              cache[i].is_free = true;
              cache[i].is_accessed = false;
              cache[i].is_dirty = false;
              idx = i;
              break;
            }

          /* Advance in a circular way. */
          i = (i + 1) % CACHE_SIZE;
        }
    }

  /* Replace each field with new one. */
  cache[idx].disk_sector = disk_sector;
  cache[idx].open_cnt++;
  cache[idx].is_free = false;
  cache[idx].is_accessed = true;
  cache[idx].is_dirty = is_dirty;
  block_read (fs_device, cache[idx].disk_sector, 
    &cache[idx].block);

  return idx;
}
