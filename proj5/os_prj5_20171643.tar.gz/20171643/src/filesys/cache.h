#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H

#include "devices/block.h"
#include "threads/synch.h"
#include "filesys/off_t.h"

/* This header provides a buffer cache for enhancing an
   efficiency of disk I/O in the pintOS file system. 
   
   The buffer cache here is implemented via 'Clock (Second Chance)
   Algorithm', which iterates the linear buffer in circular way,
   with finding the un-accessed sector-sized slot when the cache
   is full. 
   
   When the system operates disk I/O, every request must be operated
   via 'inode structure' defined in 'filesys/inode.h', that is, inode.h
   will use this header file to give the system the efficient performance. */

/* Interfaces of buffer cache. */
void cache_init (void);
int cache_access_entry (block_sector_t disk_sector, bool is_dirty);
void cache_read_entry (int, off_t, uint8_t *, int, int);
void cache_write_entry (int, off_t, uint8_t *, int, int);
void cache_flush (void);

#endif 
