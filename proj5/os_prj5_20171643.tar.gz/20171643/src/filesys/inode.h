#ifndef FILESYS_INODE_H
#define FILESYS_INODE_H

#include <stdbool.h>
#include "devices/block.h"
#include "filesys/off_t.h"

/* The most notable feature of the new inode structure of 
   project 5 phase is that it can handle extensible files. 
   
   Before the fifth phase, the former linear file system of pintOS
   suffered the existing external fragementation, as written in 
   the manual PDF. And also it suffers impossible file growth problem.
   
   Now, these problems have been solved by on-disk structure below. 
   
   +----------------------------------------------------------------+
   |on-disk | root-dir |         | root-dir |                       |
   | inode  | on-disk  | bit map |  entries |       free space      |
   |        |  inode   |         |          |                       |
   +----------------------------------------------------------------+
    ~> FCB(File Control Block, a.k.a 'inode')s reside in free space,
       with related data sectors.
    ~> Each inode structure is sector-sized, that is 512B. It means
       there can be up to 128 indirect block pointers.
    ~> But you know, there're some additional data in inode-sector,
       so we need a compact design.
    ~> I choose to design with inode-sector of 16 block pointers 
       consist of 5 direct pointer, 10 indirect pointers, and only 
       one double indirect pointer.
    ~> With these pointers and 'indexed inodes' concept, problems
       of former pintOS will be resolved, since it allows files to 
       grow whenever free space is available.
    
    The details will be introduced in comments in 'inode.c' file. 
   */

struct bitmap;

void inode_init (void);
bool inode_create (block_sector_t, off_t, bool);
struct inode *inode_open (block_sector_t);
struct inode *inode_reopen (struct inode *);
block_sector_t inode_get_inumber (const struct inode *);
void inode_close (struct inode *);
void inode_remove (struct inode *);
off_t inode_read_at (struct inode *, void *, off_t size, off_t offset);
off_t inode_write_at (struct inode *, const void *, off_t size, off_t offset);
void inode_deny_write (struct inode *);
void inode_allow_write (struct inode *);
off_t inode_length (const struct inode *);
bool inode_get_is_dir (const struct inode *);
int inode_get_open_cnt (const struct inode *);
bool inode_set_parent (block_sector_t parent, block_sector_t child);
block_sector_t inode_get_parent (const struct inode *);
void inode_lock_acquire (const struct inode *inode);
void inode_lock_release (const struct inode *inode);

/* Indicate the error status. */
#define INODE_ERROR -1

#endif /* filesys/inode.h */
