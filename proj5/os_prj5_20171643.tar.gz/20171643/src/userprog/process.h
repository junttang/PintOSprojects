#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

/* Macros for readability of codes (child list iteration codes) */
#define ITERATE_C_LIST iter=list_begin(c_list);iter!=list_end(c_list);iter=list_next(iter)
// ITERATE_C_LIST: repeat the list data structure iteratively 
#define EACH_CHILD (list_entry(iter, struct thread, child_elem))
// EACH_CHILD: get the individual entry from the list data structure

tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);

#endif /* userprog/process.h */
